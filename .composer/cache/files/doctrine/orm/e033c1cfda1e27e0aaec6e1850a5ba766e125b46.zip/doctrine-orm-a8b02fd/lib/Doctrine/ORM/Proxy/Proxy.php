<?php

declare(strict_types=1);

namespace Doctrine\ORM\Proxy;

use Doctrine\Common\Proxy\Proxy as BaseProxy;

/**
 * Interface for proxy classes.
 */
interface Proxy extends BaseProxy
{
}
